
<div id="footer" style = "background-color: orange; height:40px; width:1200px;">
	<center><h2 style = "padding:10px;">Designed & Developed By  </h2></center>
	<ul>
		<li style = "display:inline-block;margin:60px; margin-top: 10px;"> 
		<img src ="images/akash.jpeg" style ="width:150px; height:170px; border-radius:100px; border:4.5px solid grey;">	<center><h3>Akash Mohan Singh <br>MCA 2nd Yr</h3></center></img>
		</li>
		<li style = "display:inline-block; margin:60px; margin-top:10px;"> <img src ="images/singh.jpg" style ="width:148px; height:170px; border-radius:100px; border:4.5px solid grey;">
	<center>	<h3>	Abha Singh<br>MCA 2nd Yr</h3></center></img>
		</li>
		<li style = "display:inline-block;margin:60px; margin-top:10px;"> <img src ="images/sri.jpeg" style ="width:150px; height:170px; border-radius:100px; border:4.5px solid grey;">	<center><h3>
		Akash Srivastava  <br>MCA 2nd Yr</h3></center></img>
		</li>
		<li style = "display:inline-block;margin:60px; margin-top: 10px;"><img src ="images/maurya.jpeg" style ="width:150px; height:170px; border-radius:100px; border:4.5px solid grey;"><center><h3> Abhishek Maurya <br>MCA 2nd Yr</h3></center></img>
			
		</li>
	</ul>
	
</div>
<div style ="background-color: black; width:1200px; height:40px; margin-top:270px;">
	<center><h2 style ="color:white; padding: 7px;">BHU Students 2021 &copy; Project</h2></center>
	</div>
