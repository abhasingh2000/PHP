<div id="menu">
	<ul>
		<li><a href="index.php">Home</a></li>
		
		<li><a href="#">Student Zone</a>
			<ul>
				<li><a href="home.php">New Admission</a></li>
				<li><a href="edit.php">Edit Record</a></li>
			</ul>
		</li>
			
		<li><a href="#">Faculty Zone</a>
			<ul>
				<li><a href="viewRecord.php">View Record</a></li>
			</ul>
		</li>
		
		<li><a href="#">Examination</a>
			<ul>
				<li><a href="test.php">Test</a></li>
				<li><a href="result.php">Result</a></li>
			</ul>
		</li>
	</ul>
</div>